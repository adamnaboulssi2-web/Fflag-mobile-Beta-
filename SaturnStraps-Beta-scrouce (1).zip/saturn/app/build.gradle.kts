plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.robloxflagmanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.robloxflagmanager"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
}
