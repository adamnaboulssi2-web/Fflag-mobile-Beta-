Run gradle assembleDebug
Starting a Gradle Daemon (subsequent builds will be faster)
> Task :app:preBuild UP-TO-DATE
> Task :app:preDebugBuild UP-TO-DATE
> Task :app:mergeDebugNativeDebugMetadata NO-SOURCE
> Task :app:checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :app:generateDebugResValues
> Task :app:checkDebugAarMetadata
> Task :app:mapDebugSourceSetPaths
> Task :app:generateDebugResources
> Task :app:mergeDebugResources
> Task :app:packageDebugResources
> Task :app:createDebugCompatibleScreenManifests
> Task :app:extractDeepLinksDebug
> Task :app:parseDebugLocalResources

> Task :app:processDebugMainManifest FAILED
/home/runner/work/Fflag-mobile-Beta-/Fflag-mobile-Beta-/saturn/app/src/main/AndroidManifest.xml Error:

	uses-sdk:minSdkVersion 23 cannot be smaller than version 24 declared in library [dev.rikka.shizuku:api:13.1.5] /home/runner/.gradle/caches/8.9/transforms/e6fa02524ba31baa8027e789b54cdbe0/transformed/api-13.1.5/AndroidManifest.xml as the library might be using APIs not available in 23
	Suggestion: use a compatible library with a minSdk of at most 23,
		or increase this project's minSdk version to at least 24,
		or use tools:overrideLibrary="rikka.shizuku.api" to force usage (may lead to runtime failures)
See https://developer.android.com/r/studio-ui/build/manifest-merger for more information about the manifest merger.

gradle/actions: Writing build results to /home/runner/work/_temp/.gradle-actions/build-results/__run_3-1794170817191.json

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':app:processDebugMainManifest'.
> Manifest merger failed : uses-sdk:minSdkVersion 23 cannot be smaller than version 24 declared in library [dev.rikka.shizuku:api:13.1.5] /home/runner/.gradle/caches/8.9/transforms/e6fa02524ba31baa8027e789b54cdbe0/transformed/api-13.1.5/AndroidManifest.xml as the library might be using APIs not available in 23
  	Suggestion: use a compatible library with a minSdk of at most 23,
  		or increase this project's minSdk version to at least 24,
10 actionable tasks: 10 executed
  		or use tools:overrideLibrary="rikka.shizuku.api" to force usage (may lead to runtime failures)

* Try:
> Run with --stacktrace option to get the stack trace.
> Run with --info or --debug option to get more log output.
> Run with --scan to get full insights.
> Get more help at https://help.gradle.org.

BUILD FAILED in 12s
Error: Process completed with exit code 1.
0s
3s
0s
0s

// Add these imports at the top of MainActivity.kt
import android.net.Uri
import android.widget.ImageView
import android.widget.GridLayout
import org.json.JSONArray

// Add these properties inside MainActivity
private val skySides = arrayOf(
    "Right", "Left", "Top", "Bottom", "Front", "Back"
)

private val skyImages = mutableMapOf<String, Uri?>()
private lateinit var skyStatus: TextView

private var selectedSkySide = "Right"

private val skyPicker =
    registerForActivityResult(
        android.app.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            skyImages[selectedSkySide] = uri
            skyStatus.text = "$selectedSkySide image added!"
            buildSkyboxStudio()
        }
    }

// Add this function inside MainActivity
private fun buildSkyboxStudio() {
    val layout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
    }

    layout.addView(TextView(this).apply {
        text = "SATURNSTRAPS SKYBOX STUDIO"
        textSize = 22f
        setTextColor(Color.WHITE)
    })

    layout.addView(TextView(this).apply {
        text = "Choose an image for each side of your skybox."
        textSize = 14f
    })

    val grid = GridLayout(this).apply {
        columnCount = 2
    }

    skySides.forEach { side ->
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }

        val preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                150, 110
            )
            scaleType = ImageView.ScaleType.CENTER_CROP

            val uri = skyImages[side]
            if (uri != null) {
                setImageURI(uri)
            } else {
                setBackgroundColor(Color.DKGRAY)
            }
        }

        val choose = Button(this).apply {
            text = "Choose $side"
            setOnClickListener {
                selectedSkySide = side
                skyPicker.launch("image/*")
            }
        }

        card.addView(preview)
        card.addView(choose)
        grid.addView(card)
    }

    layout.addView(grid)

    skyStatus = TextView(this).apply {
        text = "Select images to build your skybox."
        textSize = 14f
    }
    layout.addView(skyStatus)

    layout.addView(Button(this).apply {
        text = "Export Skybox Settings"
        setOnClickListener {
            exportSkyboxSettings()
        }
    })

    setContentView(layout)
}

// Export the selected image URIs as a JSON design file.
// This does not install or inject assets into Roblox.
private fun exportSkyboxSettings() {
    val json = JSONObject()

    skySides.forEach { side ->
        json.put(side, skyImages[side]?.toString() ?: "")
    }

    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        type = "application/json"
        putExtra(
            Intent.EXTRA_TITLE,
            "SaturnStraps-Skybox.json"
        )
    }

    pendingSkyboxJson = json.toString(2)
    skyExportLauncher.launch("SaturnStraps-Skybox.json")
}

private var pendingSkyboxJson = ""

private val skyExportLauncher =
    registerForActivityResult(
        android.app.ActivityResultContracts.CreateDocument(
            "application/json"
        )
    ) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use {
                it.write(pendingSkyboxJson.toByteArray())
            }
            skyStatus.text = "Skybox settings exported!"
        }
    }
