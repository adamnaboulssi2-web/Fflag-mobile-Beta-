# Roblox FFlag Manager (Android source)

A small Android project for editing FastFlag JSON and exporting it as `ClientAppSettings.json`. It also checks whether Shizuku is running and requests Shizuku permission.

## Important limitation
This starter app does **not** automatically inject flags into Roblox. Android app sandboxing protects Roblox's private data directory; Shizuku permission does not automatically grant access to another app's private files. The app therefore exports a JSON file rather than claiming that flags have been applied.

The example texture flags are examples only. Roblox may ignore flags that are unsupported, removed, or not allowlisted by the current client.

## Build
Open this folder as an Android project in Android Studio, or push it to GitHub and use the included Actions workflow. The workflow builds a debug APK and uploads it as an artifact.

Minimum Android version: Android 6.0 (API 23). Intended for testing on Android 11.
