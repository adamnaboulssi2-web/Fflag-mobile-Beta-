plugins { id("com.android.application") }

android {
    namespace = "com.saturnstraps"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.saturnstraps"
        minSdk = 24
        targetSdk = 30
        versionCode = 1
        versionName = "1.0.0"
    }
}
