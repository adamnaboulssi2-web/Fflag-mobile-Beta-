package com.saturnstraps;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 41;
    private TextView status;
    private Uri treeUri;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101522);

        TextView title = new TextView(this);
        title.setText("SATURNSTRAPS");
        title.setTextSize(27);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Roblox configuration cleaner");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFFB9C7DF);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 8;
        root.addView(subtitle, sp);

        Button choose = new Button(this);
        choose.setText("1. Select Roblox folder");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 36;
        root.addView(choose, bp);
        choose.setOnClickListener(v -> chooseFolder());

        Button scan = new Button(this);
        scan.setText("2. Find RobloxFFlags file");
        root.addView(scan, new LinearLayout.LayoutParams(-1, -2));
        scan.setOnClickListener(v -> scanFolder());

        Button remove = new Button(this);
        remove.setText("3. Delete RobloxFFlags file");
        root.addView(remove, new LinearLayout.LayoutParams(-1, -2));
        remove.setOnClickListener(v -> deleteFlagFile());

        status = new TextView(this);
        status.setText("Select the folder that contains RobloxFFlags first. The app will only remove a file with that exact name.");
        status.setTextSize(14);
        status.setTextColor(0xFFFFFFFF);
        status.setPadding(4, 26, 4, 4);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Nothing is changed until you press Delete. Android may prevent access to Roblox's private app storage; choose an accessible folder using the system picker.");
        note.setTextSize(12);
        note.setTextColor(0xFF9EABC0);
        note.setPadding(4, 24, 4, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                   Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_FOLDER);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            treeUri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(treeUri, flags);
            status.setText("Folder selected. Tap Find to check for RobloxFFlags.");
        }
    }

    private Uri findFile() {
        if (treeUri == null) return null;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, DocumentsContract.getTreeDocumentId(treeUri));
        String[] projection = { DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                                DocumentsContract.Document.COLUMN_MIME_TYPE };
        try (Cursor c = getContentResolver().query(children, projection, null, null, null)) {
            if (c == null) return null;
            while (c.moveToNext()) {
                String name = c.getString(1);
                String mime = c.getString(2);
                if ("RobloxFFlags".equals(name) || "RobloxFFlags.json".equals(name)) {
                    return DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(0));
                }
            }
        } catch (Exception e) {
            status.setText("Could not read this folder: " + e.getMessage());
        }
        return null;
    }

    private void scanFolder() {
        if (treeUri == null) { status.setText("Select the Roblox folder first."); return; }
        Uri file = findFile();
        status.setText(file == null ? "No file named RobloxFFlags or RobloxFFlags.json found directly in this folder."
                                    : "Found the RobloxFFlags file. Press Delete to remove only that file.");
    }

    private void deleteFlagFile() {
        if (treeUri == null) { status.setText("Select the Roblox folder first."); return; }
        Uri file = findFile();
        if (file == null) { status.setText("No matching file found. Nothing was deleted."); return; }
        try {
            boolean deleted = DocumentsContract.deleteDocument(getContentResolver(), file);
            status.setText(deleted ? "RobloxFFlags file deleted." : "Android did not delete the file.");
            Toast.makeText(this, deleted ? "File deleted" : "Delete failed", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            status.setText("Delete failed: " + e.getMessage());
        }
    }
}
