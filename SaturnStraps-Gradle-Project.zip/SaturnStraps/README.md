# SaturnStraps

Android Gradle project for a small Roblox configuration cleaner.

## Build
- Android Gradle Plugin: 8.6.1
- Gradle wrapper target: 8.7
- JDK: 17
- compileSdk: 35
- minSdk: 24 (works on Android 11 / API 30)

Open this folder in Android Studio or build with Gradle 8.7:
`gradle assembleDebug`

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## How it works
The app uses Android's Storage Access Framework. The user chooses an accessible folder, scans it, then explicitly confirms deletion. It only looks for `RobloxFFlags` or `RobloxFFlags.json` directly inside the selected folder. It does not access Roblox's private app data or recursively delete anything.

Android 11 may block access to some protected locations. If the system folder picker does not allow selecting the Roblox folder, the app cannot bypass that restriction without special access/root.
