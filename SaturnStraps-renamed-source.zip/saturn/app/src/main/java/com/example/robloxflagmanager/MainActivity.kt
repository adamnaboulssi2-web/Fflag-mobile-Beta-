package com.example.robloxflagmanager

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val requestCode = 4107
    private lateinit var status: TextView
    private lateinit var flagsBox: EditText
    private var exportJson: String = "{}"

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, grantResult ->
        if (code == requestCode) {
            status.text = if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED)
                "Shizuku permission granted. JSON export is ready; direct Roblox-private-folder access is not guaranteed."
            else "Shizuku permission was not granted."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "SaturnStraps"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "Edit flags as JSON, then export ClientAppSettings.json."
            textSize = 14f
        })
        status = TextView(this).apply {
            text = "Shizuku: checking…"
            textSize = 14f
            setPadding(0, 18, 0, 18)
        }
        layout.addView(status)

        flagsBox = EditText(this).apply {
            setText("{\n  \"DFIntTextureQualityOverride\": \"3\",\n  \"DFFlagTextureQualityOverrideEnabled\": \"True\"\n}")
            minLines = 8
            gravity = android.view.Gravity.TOP
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 13f
        }
        layout.addView(flagsBox, LinearLayout.LayoutParams(-1, 0, 1f))

        layout.addView(Button(this).apply {
            text = "Check / request Shizuku permission"
            setOnClickListener { checkShizuku() }
        })
        layout.addView(Button(this).apply {
            text = "Export ClientAppSettings.json"
            setOnClickListener {
                try {
                    val obj = JSONObject(flagsBox.text.toString())
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "ClientAppSettings.json")
                    }
                    exportJson = obj.toString(2)
                    startActivityForResult(intent, 4108)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Invalid JSON: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "Important: Android protects Roblox's private app data. Shizuku permission alone does not guarantee access to Roblox's private folder. This starter app exports a settings file; it does not claim to inject or activate flags automatically."
            textSize = 12f
            setPadding(0, 14, 0, 0)
        })
        setContentView(layout)
        checkShizuku()
    }

    private fun checkShizuku() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    status.text = "Shizuku: connected; permission granted."
                } else {
                    status.text = "Shizuku: connected; permission needed."
                    Shizuku.requestPermission(requestCode)
                }
            } else {
                status.text = "Shizuku: not running. Start Shizuku first."
            }
        } catch (e: Exception) {
            status.text = "Shizuku status unavailable: ${e.message}"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4108 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { it.write(exportJson.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "JSON exported.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}
